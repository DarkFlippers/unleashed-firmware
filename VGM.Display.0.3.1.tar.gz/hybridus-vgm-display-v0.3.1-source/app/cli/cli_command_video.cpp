/* SPDX-License-Identifier: MIT */
#include "cli_commands.h"
#include "../video_settings.h"
#include "../settings_boot.h"
#include "../video_palette.h"
#include <string.h>
static void status(Cli*cli,const VgmConfig&c){
 cli_printf(cli,"Manual base BG=%04X FG=%04X; invert=%u mode=%s effects=%u; boot_store=%u" EOL,
  c.bg,c.fg,!!(c.flags&VGM_CONFIG_INVERT),(c.flags&VGM_CONFIG_HOST)?"host-volatile":"manual",c.effects,(unsigned)settings_boot_result());
 cli_printf(cli,"Changes are RAM-only until explicit video save (reboot). Host RGB sync never writes flash." EOL);
}
void cli_video(Cli*cli,std::string&args){
 VgmConfig c;if(!video_settings_get(&c)){cli_printf(cli,"Busy; retry" EOL);return;}
 if(args.empty()||args=="status"){status(cli,c);return;}
 if(args=="save"){
  if(!video_settings_save_snapshot(&c)){cli_printf(cli,"Busy; retry" EOL);return;}
  if(settings_request_save(&c))cli_printf(cli,"Save requested; rebooting. Check video status after reboot; boot_store=0/1 means saved/unchanged." EOL);
  else cli_printf(cli,"Save refused: unsupported flash/layout or invalid config. No flash write." EOL);
  return;
 }
 bool valid=true;
 if(args=="night"||args=="normal"||args=="mode night"||args=="mode standard"){
  // Mode changes preserve the user's accent; they never silently reset it to orange.
  uint16_t accent=c.fg?c.fg:c.bg;c.bg=0;c.fg=accent;
  c.flags=(args=="normal"||args=="mode standard")?VGM_CONFIG_INVERT:0;
 }
 else if(args=="mode host"){c.flags|=VGM_CONFIG_HOST;}
 else if(args=="mode manual"){c.flags&=~VGM_CONFIG_HOST;}
 else if(args=="invert"){c.flags^=VGM_CONFIG_INVERT;c.flags&=~VGM_CONFIG_HOST;}
 else if(args.size()==7&&args.substr(0,3)=="fg "){
  VideoPalette p={0,c.fg},out;std::string cmd="colors 0000 "+args.substr(3);
  if(video_palette_command(cmd.c_str(),p,&out)!=VideoPaletteUpdate)valid=false;
  else{c.bg=0;c.fg=out.fg;c.flags=0;}
 }
 else if(args.size()==9&&args.substr(0,8)=="effects "&&args[8]>='0'&&args[8]<='7'){c.effects=args[8]-'0';c.flags&=~VGM_CONFIG_HOST;}
 else{
  VideoPalette p={c.bg,c.fg},out;
  if(video_palette_command(args.c_str(),p,&out)!=VideoPaletteUpdate)valid=false;
  else{c.bg=out.bg;c.fg=out.fg;c.flags=0;}
 }
 if(!valid){
  cli_printf(cli,"Usage: video [status|save|mode manual|mode host|mode standard|mode night|invert|fg FFFF|effects 0..7]" EOL);
  cli_printf(cli,"       video [normal|night|mono|green|reset|colors BBBB FFFF]" EOL);
  cli_printf(cli,"Effects bits: 1 scanline grid, 2 margin bezel, 4 UART screen-frame activity. fg uses black background." EOL);return;
 }
 if(!video_settings_set(&c)){cli_printf(cli,"Busy; retry" EOL);return;}status(cli,c);
}
