/* SPDX-License-Identifier: MIT
 * Decorative quick-settings-inspired bezel. No control input/state is implied.
 * Internal raster 320x240; all writes strictly x4..27 or x292..315.
 * Original tiny glyph geometry; no external logos/fonts/artwork.
 */
#pragma once
#include <stdint.h>
#include <stddef.h>
static inline void vgm_panel_span(uint16_t* b,unsigned a,unsigned z,uint16_t c){for(unsigned x=a;x<=z;x++)b[x]=c;}
static inline void vgm_panel_box(uint16_t* b,unsigned y,unsigned x,unsigned top,unsigned w,unsigned h,uint16_t c){
 if(y<top||y>=top+h)return;
 if(y==top||y==top+h-1){vgm_panel_span(b,x+1,x+w-2,c);return;}
 b[x]=c;b[x+w-1]=c;
}
static inline void vgm_panel_glyph(uint16_t* b,unsigned y,unsigned x,unsigned top,const uint8_t rows[7],uint16_t c){
 if(y<top||y>=top+7)return;
 const uint8_t row=rows[y-top];for(unsigned k=0;k<5;k++)if(row&(1u<<(4-k)))b[x+k]=c;
}
static inline void vgm_side_panels(uint16_t* b,unsigned y,uint16_t edge,uint16_t dim){
 /* A narrow split rail per side, without a full rounded picture-frame. */
 if(y>=19&&y<=219){b[4]=dim;b[27]=dim;b[292]=dim;b[315]=dim;}
 if(y==18||y==220){vgm_panel_span(b,6,25,dim);vgm_panel_span(b,294,313,dim);}
 if(y==28||y==125||y==204){vgm_panel_span(b,7,24,dim);vgm_panel_span(b,295,312,dim);}
 if(y==23){vgm_panel_span(b,9,12,edge);vgm_panel_span(b,17,20,dim);vgm_panel_span(b,297,300,dim);vgm_panel_span(b,305,308,edge);}
 /* Left: brightness and volume tracks. Fixed ornaments, NOT live readouts. */
 if(y>=48&&y<=113){b[10]=dim;b[21]=dim;}
 if(y==48||y==113){vgm_panel_span(b,8,12,dim);vgm_panel_span(b,19,23,dim);}
 if(y==60||y==72||y==84||y==96||y==108){b[7]=dim;b[24]=dim;}
 if(y>=65&&y<=69)vgm_panel_span(b,7,13,edge);
 if(y>=87&&y<=91)vgm_panel_span(b,18,24,edge);
 static const uint8_t sun[7]={4,21,14,31,14,21,4};
 static const uint8_t speaker[7]={1,3,31,31,31,3,1};
 static const uint8_t bt[7]={4,6,21,14,21,6,4};
 static const uint8_t dummy[7]={14,17,21,17,17,17,14};
 static const uint8_t vibration[7]={4,10,21,21,21,10,4};
 static const uint8_t mute[7]={17,10,4,10,17,0,0};
 static const uint8_t portrait[7]={14,10,10,10,10,10,14};
 static const uint8_t landscape[7]={0,31,17,17,17,31,0};
 vgm_panel_glyph(b,y,8,35,sun,edge);vgm_panel_glyph(b,y,19,35,speaker,edge);
 /* Right: button-like outlines with no enabled/disabled/check state. */
 const unsigned rows[3]={37,90,143};
 for(unsigned i=0;i<3;i++){vgm_panel_box(b,y,295,rows[i],15,35,dim);}
 vgm_panel_glyph(b,y,300,44,bt,edge);vgm_panel_glyph(b,y,300,58,dummy,dim);
 vgm_panel_glyph(b,y,300,97,vibration,edge);vgm_panel_glyph(b,y,300,111,mute,dim);
 vgm_panel_glyph(b,y,297,151,portrait,edge);vgm_panel_glyph(b,y,304,163,landscape,dim);
 /* Lower left: grouped shortcut tiles; separators echo the quick-panel grid. */
 for(unsigned i=0;i<2;i++){vgm_panel_box(b,y,7,136+i*32,17,24,dim);}
 vgm_panel_glyph(b,y,13,144,bt,edge);vgm_panel_glyph(b,y,13,176,mute,edge);
 if(y==211){vgm_panel_span(b,9,13,dim);vgm_panel_span(b,18,22,dim);vgm_panel_span(b,297,301,dim);vgm_panel_span(b,306,310,dim);}
}
