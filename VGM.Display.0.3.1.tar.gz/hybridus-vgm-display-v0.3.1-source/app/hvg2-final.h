/* SPDX-License-Identifier: MIT — final coordinated HVG2 wire contract. */
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#define HVG2_WIRE_SIZE 16u
typedef enum {Hvg2SetManual=1,Hvg2SetSync=2,Hvg2Save=3} Hvg2Opcode;
typedef struct {uint16_t revision,fg;uint8_t effects;bool invert;Hvg2Opcode opcode;} Hvg2Command;
typedef enum {Hvg2Ok,Hvg2Length,Hvg2Format,Hvg2Checksum,Hvg2Duplicate,Hvg2Stale,Hvg2Conflict} Hvg2Result;
typedef struct {bool valid;Hvg2Command current;} Hvg2RevisionState;
uint16_t hvg2_crc16(const uint8_t*,size_t);
bool hvg2_encode(const Hvg2Command*,uint8_t out[HVG2_WIRE_SIZE]);
Hvg2Result hvg2_decode(const uint8_t*,size_t,Hvg2Command*);
Hvg2Result hvg2_check_revision(const Hvg2RevisionState*,const Hvg2Command*);
void hvg2_commit_revision(Hvg2RevisionState*,const Hvg2Command*);
/* SAVE is full snapshot: apply fg/invert/effects, disable sync, persist manual.
 * SET_SYNC explicitly enables sync and subsequent coalesced updates are volatile.
 * No codec function writes hardware or implies apply/save acknowledgement. */
