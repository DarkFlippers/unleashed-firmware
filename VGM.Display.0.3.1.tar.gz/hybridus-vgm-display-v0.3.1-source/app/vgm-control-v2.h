/* SPDX-License-Identifier: MIT — coordinated HVG2 receiver. */
#pragma once
#include "hvg2-final.h"
#include "settings_store.h"
typedef struct {Hvg2RevisionState revision;bool save_queued;VgmConfig snapshot;} VgmControlV2;
typedef enum {VgmV2Frame,VgmV2Applied,VgmV2Duplicate,VgmV2Invalid,VgmV2Stale,VgmV2Busy,VgmV2SaveAlreadyStored,VgmV2SaveDenied} VgmControlV2Result;
VgmControlV2Result vgm_control_v2_receive(VgmControlV2*,uint8_t,const uint8_t*,size_t);
/* UART task only, AFTER pb_release and outside frame/settings locks. No flash IO. */
bool vgm_control_v2_request_pending_save(VgmControlV2*);
