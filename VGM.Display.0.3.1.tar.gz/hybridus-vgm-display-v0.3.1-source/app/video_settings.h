/* SPDX-License-Identifier: MIT */
#pragma once
#include "settings_store.h"
#include "control_wire.h"
#ifdef __cplusplus
extern "C" {
#endif
void video_settings_init(void);
bool video_settings_get(VgmConfig*);
bool video_settings_save_snapshot(VgmConfig*);
bool video_settings_command(uint8_t orientation,const uint8_t* bitmap,const VgmConfig* config);
bool video_settings_set(const VgmConfig*);
/* Atomically accept bitmap plus optional host palette; no flash writes. */
bool video_settings_frame(uint8_t orientation,const uint8_t*,const HvgmSettings*,bool* host_applied);
#ifdef __cplusplus
}
#endif
