/* SPDX-License-Identifier: MIT */
#include "settings_store.h"
#include <string.h>
static uint32_t get32(const uint8_t*p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static void put32(uint8_t*p,uint32_t n){for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(n>>(i*8));}
uint32_t vgm_crc32(const uint8_t*p,size_t n){uint32_t c=~0u;for(size_t i=0;i<n;i++){c^=p[i];for(unsigned k=0;k<8;k++)c=(c>>1)^((c&1)?0xedb88320u:0);}return ~c;}
bool vgm_config_valid(const VgmConfig*c){return c&&!(c->flags&~3u)&&!(c->effects&~7u);}
static bool same(VgmConfig a,VgmConfig b){return a.bg==b.bg&&a.fg==b.fg&&a.flags==b.flags&&a.effects==b.effects;}
static bool blank(const uint8_t*p,size_t n){for(size_t i=0;i<n;i++)if(p[i]!=255)return false;return true;}
static void pack(uint8_t*p,const VgmConfig*c,uint32_t gen){
 memset(p,255,VGM_PAGE_SIZE);memcpy(p,"HVPST003",8);put32(p+8,gen);p[12]=(uint8_t)c->bg;p[13]=c->bg>>8;p[14]=(uint8_t)c->fg;p[15]=c->fg>>8;p[16]=c->effects;p[17]=c->flags;p[18]=1;p[19]=0;put32(p+20,vgm_crc32(p,20));
}
static bool unpack(const uint8_t*p,VgmConfig*c,uint32_t*gen){
 if(memcmp(p,"HVPST003",8)||p[18]!=1||p[19]||get32(p+20)!=vgm_crc32(p,20)||!blank(p+24,VGM_PAGE_SIZE-24))return false;
 VgmConfig v={(uint16_t)(p[12]|p[13]<<8),(uint16_t)(p[14]|p[15]<<8),p[16],p[17]};if(!vgm_config_valid(&v))return false;*c=v;*gen=get32(p+8);return true;
}
typedef struct {bool found,foreign;VgmConfig config;uint32_t gen,latest,empty[2];} Scan;
static VgmStoreResult scan(const VgmFlash*f,Scan*s){
 memset(s,0,sizeof *s);s->empty[0]=s->empty[1]=UINT32_MAX;
 uint8_t p[VGM_PAGE_SIZE];
 for(unsigned bank=0;bank<2;bank++)for(unsigned slot=0;slot<16;slot++){
  uint32_t addr=VGM_SETTINGS_A+bank*VGM_SECTOR_SIZE+slot*VGM_PAGE_SIZE;if(!f->read(f->context,addr,p,sizeof p))return VgmStoreIo;
  if(blank(p,sizeof p)){if(s->empty[bank]==UINT32_MAX)s->empty[bank]=addr;continue;}
  VgmConfig c;uint32_t gen;
  if(unpack(p,&c,&gen)){
   if(!s->found||((gen-s->gen)!=0&&(gen-s->gen)<0x80000000u)){s->config=c;s->gen=gen;s->latest=addr;s->found=true;}
  }else if(memcmp(p,"HVPST003",8))s->foreign=true; // Never erase unidentified pre-existing contents.
 }
 return s->found?VgmStoreOk:(s->foreign?VgmStoreForeign:VgmStoreEmpty);
}
VgmStoreResult vgm_store_load(const VgmFlash*f,VgmConfig*c,uint32_t*g){
 if(!f||!f->read||!c)return VgmStoreIo;
 Scan s;VgmStoreResult r=scan(f,&s);if(r==VgmStoreOk){*c=s.config;if(g)*g=s.gen;}return r;
}
VgmStoreResult vgm_store_save(const VgmFlash*f,const VgmConfig*c){
 if(!f||!f->read||!f->program||!f->erase||!vgm_config_valid(c))return VgmStoreIo;
 Scan s;VgmStoreResult r=scan(f,&s);if(r==VgmStoreIo)return r;
 if(s.found&&same(s.config,*c))return VgmStoreUnchanged;
 if(s.foreign)return VgmStoreForeign;
 unsigned active=s.found?(s.latest-VGM_SETTINGS_A)/VGM_SECTOR_SIZE:0;
 uint32_t target=s.empty[active];
 if(target==UINT32_MAX){active^=1;target=s.empty[active];}
 if(target==UINT32_MAX){
  if(!s.found)return VgmStoreForeign; // No trustworthy active bank: never guess/erase.
  // Both full: erase only bank NOT containing the newest validated record.
  active=((s.latest-VGM_SETTINGS_A)/VGM_SECTOR_SIZE)^1u;target=VGM_SETTINGS_A+active*VGM_SECTOR_SIZE;
  if(!f->erase(f->context,target))return VgmStoreIo;
 }
 uint8_t p[VGM_PAGE_SIZE],check[VGM_PAGE_SIZE];pack(p,c,s.found?s.gen+1:1);
 if(!f->program(f->context,target,p)||!f->read(f->context,target,check,sizeof check)||memcmp(p,check,sizeof p))return VgmStoreIo;
 VgmConfig verify;uint32_t gen;if(!unpack(check,&verify,&gen)||!same(verify,*c))return VgmStoreIo;
 return VgmStoreOk;
}
