/* SPDX-License-Identifier: MIT — Hybridus VGM control wire format v1. */
#ifndef HVGM_DRAFT_CONTROL_WIRE_H
#define HVGM_DRAFT_CONTROL_WIRE_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#define HVGM_WIRE_SIZE 16u
#define HVGM_WIRE_VERSION 1u
#define HVGM_FLAG_INVERT 1u
// Metadata only: FG is host-derived from the average logical RGB of three SK6805 LEDs.
#define HVGM_FLAG_SYNC 2u
#define HVGM_EFFECT_SCANLINES 1u
#define HVGM_EFFECT_BEZEL 2u
#define HVGM_EFFECT_OSD 4u

typedef struct {
    uint16_t revision;
    uint16_t bg;
    uint16_t fg;
    uint8_t flags;
    uint8_t effects;
} HvgmSettings;
typedef enum {
    HvgmOk, HvgmWrongLength, HvgmMagic, HvgmVersion, HvgmReserved,
    HvgmChecksum, HvgmDuplicate, HvgmStale, HvgmConflict
} HvgmResult;
typedef struct { bool valid; HvgmSettings current; } HvgmRevisionState;
uint16_t hvgm_crc16(const uint8_t* data,size_t size);
bool hvgm_encode(const HvgmSettings* state,uint8_t output[HVGM_WIRE_SIZE]);
HvgmResult hvgm_decode(const uint8_t* data,size_t size,HvgmSettings* output);
/* Inspect only. Commit after the state is actually accepted, never before a busy failure. */
HvgmResult hvgm_revision_check(const HvgmRevisionState* state,const HvgmSettings* incoming);
void hvgm_revision_commit(HvgmRevisionState* state,const HvgmSettings* incoming);
void hvgm_resolve_palette(const HvgmSettings* settings,uint16_t* bg,uint16_t* fg);
#endif
