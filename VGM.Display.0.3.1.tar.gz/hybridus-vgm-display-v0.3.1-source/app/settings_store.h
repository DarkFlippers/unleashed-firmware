/* SPDX-License-Identifier: MIT */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#define VGM_SETTINGS_A 0x40000u
#define VGM_SETTINGS_B 0x41000u
#define VGM_SETTINGS_END 0x42000u
#define VGM_SECTOR_SIZE 4096u
#define VGM_PAGE_SIZE 256u
typedef struct {uint16_t bg,fg;uint8_t effects,flags;} VgmConfig;
#define VGM_CONFIG_HOST 1u
#define VGM_CONFIG_INVERT 2u
typedef enum {VgmStoreOk,VgmStoreUnchanged,VgmStoreEmpty,VgmStoreForeign,VgmStoreIo,VgmStoreUnsupported} VgmStoreResult;
typedef struct {
 void* context;
 bool (*read)(void*,uint32_t,uint8_t*,size_t);
 bool (*erase)(void*,uint32_t);
 bool (*program)(void*,uint32_t,const uint8_t*);
} VgmFlash;
bool vgm_config_valid(const VgmConfig*);
uint32_t vgm_crc32(const uint8_t*,size_t);
VgmStoreResult vgm_store_load(const VgmFlash*,VgmConfig*,uint32_t*);
/* Boot-only caller; all readback, power-loss logic and wear policy in this module. */
VgmStoreResult vgm_store_save(const VgmFlash*,const VgmConfig*);
