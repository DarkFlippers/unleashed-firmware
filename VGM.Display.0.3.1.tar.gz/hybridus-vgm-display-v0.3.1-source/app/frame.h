#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "video_palette.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    const uint8_t data[1024];
} frame_t;

void frame_init();

uint32_t frame_get_clock();

uint32_t frame_get_voltage();

typedef enum {
    OrientationHorizontal = 0,
    OrientationHorizontalFlip = 1,
    OrientationVertical = 2,
    OrientationVerticalFlip = 3,
} Orientation;

void frame_parse_data(uint8_t orientation, const frame_t* frame, uint32_t timeout_ms);

// Core 0 API. Bounded lock; false means busy, no update. RAM only.
bool frame_set_color(uint16_t bg, uint16_t fg);
bool frame_get_color(VideoPalette* palette);

// Prepared on Core 0; whole pair/effects are latched together on Core 1.
typedef struct {
    VideoPalette palette;
    VideoPalette dim;
    uint8_t effects;
    uint8_t activity;
} VideoRenderSettings;
void frame_prepare_render(VideoRenderSettings* render, uint16_t bg, uint16_t fg, uint8_t effects);
bool frame_set_render(const VideoRenderSettings* settings);
void frame_link_disconnected(void);
bool frame_apply(uint8_t orientation, const frame_t* frame,
    const VideoRenderSettings* settings, uint32_t timeout_ms);

#ifdef __cplusplus
}
#endif
