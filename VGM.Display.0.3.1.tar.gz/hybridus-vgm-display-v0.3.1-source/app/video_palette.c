// SPDX-License-Identifier: MIT
#include "video_palette.h"
#include <stddef.h>
#include <string.h>

static int hex_digit(char c) {
    if(c >= '0' && c <= '9') return c - '0';
    if(c >= 'a' && c <= 'f') return c - 'a' + 10;
    if(c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static int hex_color(const char* s, uint16_t* out) {
    uint16_t value = 0;
    for(size_t i = 0; i < 4; ++i) {
        int digit = hex_digit(s[i]);
        if(digit < 0) return 0;
        value = (uint16_t)((value << 4) | (unsigned)digit);
    }
    *out = value;
    return 1;
}

VideoPaletteResult video_palette_command(
    const char* command, VideoPalette current, VideoPalette* out) {
    if(command == NULL || out == NULL) return VideoPaletteInvalid;
    /* Bounded read for a valid NUL-terminated command. */
    size_t len = 0;
    while(len < 17 && command[len] != '\0') ++len;
    if(len == 17) return VideoPaletteInvalid;
    if(len == 0 || strcmp(command, "status") == 0) return VideoPaletteQuery;

    VideoPalette result;
    if(strcmp(command, "normal") == 0 || strcmp(command, "reset") == 0) {
        result = (VideoPalette){VIDEO_PALETTE_DEFAULT_BG, VIDEO_PALETTE_DEFAULT_FG};
    } else if(strcmp(command, "night") == 0) {
        result = (VideoPalette){VIDEO_PALETTE_DEFAULT_FG, VIDEO_PALETTE_DEFAULT_BG};
    } else if(strcmp(command, "mono") == 0) {
        result = (VideoPalette){0xFFFF, 0x0000};
    } else if(strcmp(command, "green") == 0) {
        result = (VideoPalette){0x0000, 0x07E0};
    } else if(strcmp(command, "invert") == 0) {
        result = (VideoPalette){current.fg, current.bg};
    } else if(len == 16 && memcmp(command, "colors ", 7) == 0 && command[11] == ' ') {
        if(!hex_color(command + 7, &result.bg) || !hex_color(command + 12, &result.fg)) {
            return VideoPaletteInvalid;
        }
    } else {
        return VideoPaletteInvalid;
    }
    *out = result;
    return VideoPaletteUpdate;
}
