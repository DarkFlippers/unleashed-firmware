/* SPDX-License-Identifier: MIT — coordinated HVG2 receiver. */
#include "vgm-control-v2.h"
#include "video_settings.h"
#include "settings_boot.h"
#include "frame.h"
/* Global per power cycle: never perpetually reset watchdog due to repeated SAVE. */
static bool vgm_v2_save_issued;
static bool v2_config_equal(VgmConfig a,VgmConfig b){return a.bg==b.bg&&a.fg==b.fg&&a.effects==b.effects&&a.flags==b.flags;}
static VgmControlV2Result draw_only(uint8_t o,const uint8_t*p,VgmControlV2Result r){bool applied=false;return video_settings_frame(o,p,NULL,&applied)?r:VgmV2Busy;}
VgmControlV2Result vgm_control_v2_receive(VgmControlV2*s,uint8_t o,const uint8_t*p,size_t n){
 if(!s||!p||o>3||n!=1040)return VgmV2Invalid;
 Hvg2Command command;if(hvg2_decode(p+1024,16,&command)!=Hvg2Ok)return draw_only(o,p,VgmV2Invalid);
 Hvg2Result revision=hvg2_check_revision(&s->revision,&command);
 if(revision!=Hvg2Ok&&revision!=Hvg2Duplicate)return draw_only(o,p,VgmV2Stale);
 VgmConfig config={0,command.fg,command.effects,(uint8_t)((command.invert?VGM_CONFIG_INVERT:0)|(command.opcode==Hvg2SetSync?VGM_CONFIG_HOST:0))};
 /* This explicit command works from default/manual without any USB CLI step. */
 if(!video_settings_command(o,p,&config))return VgmV2Busy;
 hvg2_commit_revision(&s->revision,&command);
 if(command.opcode==Hvg2Save){
  const VgmStoreResult boot=settings_boot_result();
  if((boot==VgmStoreOk||boot==VgmStoreUnchanged)&&v2_config_equal(config,settings_boot_config()))return VgmV2SaveAlreadyStored;
  /* Unknown part/layout, foreign data or prior IO failure must never reboot-loop. */
  if(vgm_v2_save_issued||(boot!=VgmStoreOk&&boot!=VgmStoreUnchanged&&boot!=VgmStoreEmpty))return VgmV2SaveDenied;
  s->snapshot=config;s->save_queued=true;
 }
 return revision==Hvg2Duplicate?VgmV2Duplicate:VgmV2Applied;
}
bool vgm_control_v2_request_pending_save(VgmControlV2*s){
 if(!s||!s->save_queued||vgm_v2_save_issued)return false;
 s->save_queued=false;vgm_v2_save_issued=true;
 /* settings_request_save ONLY stages scratch+watchdog; early next boot writes. */
 return settings_request_save(&s->snapshot);
}
