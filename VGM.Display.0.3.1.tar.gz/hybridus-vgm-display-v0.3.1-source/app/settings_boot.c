/* SPDX-License-Identifier: MIT */
#include "settings_boot.h"
#include <string.h>
#include <hardware/flash.h>
#include <hardware/sync.h>
#include <hardware/watchdog.h>
#include <hardware/structs/watchdog.h>
#include <hardware/structs/psm.h>
#include <hardware/regs/psm.h>
#include <pico/stdlib.h>
#define SAVE_MAGIC 0x33535648u
extern uint8_t __flash_binary_end, __vgm_settings_a, __vgm_settings_b, __vgm_settings_end;
static VgmConfig config={0,0xfc00,0,0};
static VgmStoreResult result=VgmStoreEmpty;
static bool initialized;
static bool read_page(void*ctx,uint32_t off,uint8_t*d,size_t n){(void)ctx;if(off<VGM_SETTINGS_A||n>VGM_SETTINGS_END-off||off>=VGM_SETTINGS_END)return false;memcpy(d,(const void*)(uintptr_t)(XIP_BASE+off),n);return true;}
static bool erase_sector(void*ctx,uint32_t off){(void)ctx;if(off!=VGM_SETTINGS_A&&off!=VGM_SETTINGS_B)return false;flash_range_erase(off,VGM_SECTOR_SIZE);return true;}
static bool program_page(void*ctx,uint32_t off,const uint8_t*d){(void)ctx;if(off<VGM_SETTINGS_A||off>=VGM_SETTINGS_END||off%VGM_PAGE_SIZE)return false;flash_range_program(off,d,VGM_PAGE_SIZE);return true;}
static uint32_t trigger_crc(uint32_t a,uint32_t b){uint32_t v[3]={SAVE_MAGIC,a,b};return vgm_crc32((const uint8_t*)v,sizeof v);}
void settings_boot_init(void){
 if(initialized)return;
 initialized=true;
 uint32_t trigger[4];for(unsigned i=0;i<4;i++)trigger[i]=watchdog_hw->scratch[i];watchdog_hw->scratch[0]=0;
 bool save=watchdog_caused_reboot()&&trigger[0]==SAVE_MAGIC&&trigger[3]==trigger_crc(trigger[1],trigger[2]);
 VgmConfig desired={(uint16_t)trigger[1],(uint16_t)(trigger[1]>>16),(uint8_t)trigger[2],(uint8_t)(trigger[2]>>8)};
 save=save&&!(trigger[2]&0xffff0000u)&&vgm_config_valid(&desired);
 // Early boot only: explicitly hold Core1 in reset, no DVI, USB, RTOS or DMA exists yet.
 // Release it back to boot-ROM FIFO wait after commit, BEFORE later core launch.
 hw_set_bits(&psm_hw->frce_off,PSM_FRCE_OFF_PROC1_BITS);
 while(!(psm_hw->frce_off&PSM_FRCE_OFF_PROC1_BITS))tight_loop_contents();
 if((uintptr_t)&__flash_binary_end>(uintptr_t)&__vgm_settings_a||
    (uintptr_t)&__vgm_settings_a!=XIP_BASE+VGM_SETTINGS_A||
    (uintptr_t)&__vgm_settings_b!=XIP_BASE+VGM_SETTINGS_B||
    (uintptr_t)&__vgm_settings_end!=XIP_BASE+VGM_SETTINGS_END){result=VgmStoreUnsupported;hw_clear_bits(&psm_hw->frce_off,PSM_FRCE_OFF_PROC1_BITS);return;}
 uint32_t irq=save_and_disable_interrupts();
 // RDID is performed only now: SDK flash_do_cmd is in SRAM and restores XIP.
 uint8_t tx[4]={0x9f,0,0,0},rx[4]={0};flash_do_cmd(tx,rx,sizeof tx);
 // Fail closed: supported Winbond W25Q JEDEC family, >=512 KiB, <=16 MiB.
 bool supported=rx[1]==0xef&&(rx[2]==0x40||rx[2]==0x60)&&rx[3]>=0x13&&rx[3]<=0x18;
 if(supported){
  const VgmFlash f={NULL,read_page,erase_sector,program_page};
  result=vgm_store_load(&f,&config,NULL);
  if(result==VgmStoreEmpty)config.effects=0x02u;
  if(save){result=vgm_store_save(&f,&desired);VgmConfig saved;if(vgm_store_load(&f,&saved,NULL)==VgmStoreOk)config=saved;}
 }else result=VgmStoreUnsupported;
 restore_interrupts(irq);
 hw_clear_bits(&psm_hw->frce_off,PSM_FRCE_OFF_PROC1_BITS);
}
VgmConfig settings_boot_config(void){return config;}
VgmStoreResult settings_boot_result(void){return result;}
bool settings_request_save(const VgmConfig*c){
 if(!initialized||!vgm_config_valid(c)||result==VgmStoreUnsupported)return false;
 uint32_t a=(uint32_t)c->bg|((uint32_t)c->fg<<16),b=c->effects|((uint32_t)c->flags<<8);
 watchdog_hw->scratch[0]=0;watchdog_hw->scratch[1]=a;watchdog_hw->scratch[2]=b;watchdog_hw->scratch[3]=trigger_crc(a,b);
 __dmb();watchdog_hw->scratch[0]=SAVE_MAGIC;__dmb();watchdog_reboot(0,0,100);return true;
}
