/* SPDX-License-Identifier: MIT */
#include "video_control.h"
#include "frame.h"
#include "video_settings.h"
#define BITMAP_BYTES 1024u
VideoControlResult video_control_receive(HvgmRevisionState* state, uint8_t orientation,
                                         const uint8_t* data, size_t size) {
    if(!state || !data || size < BITMAP_BYTES || size > 1536u || orientation > 3)
        return VideoControlInvalidFrame;
    HvgmSettings incoming;
    VideoControlResult result = VideoControlFrame;
    const HvgmSettings* change = NULL;
    if(size == BITMAP_BYTES + HVGM_WIRE_SIZE) {
        if(hvgm_decode(data + BITMAP_BYTES, HVGM_WIRE_SIZE, &incoming) != HvgmOk) {
            result = VideoControlInvalidSettings;
        } else if((incoming.flags & HVGM_FLAG_SYNC) && incoming.bg != 0) {
            result=VideoControlInvalidSettings;
        } else {
            const HvgmResult revision = hvgm_revision_check(state, &incoming);
            if(revision == HvgmOk || revision == HvgmDuplicate) {
                change = &incoming;
                result = revision == HvgmDuplicate ? VideoControlDuplicate : VideoControlApplied;
            } else {
                result = VideoControlStale;
            }
        }
    } else if(size != BITMAP_BYTES) {
        result = VideoControlInvalidSettings;
    }
    // Invalid/missing/old settings never prevent drawing a valid first1024 frame.
    // Both frame and any new settings are published atomically by one bounded lock.
    bool applied=false;
    if(!video_settings_frame(orientation,data,change,&applied))return VideoControlBusy;
    if(change && applied) hvgm_revision_commit(state, &incoming);
    if(change && !applied) result=VideoControlFrame;
    return result;
}
