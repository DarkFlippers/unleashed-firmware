#include "control_wire.h"
#include <string.h>
static uint16_t get16(const uint8_t* p){return (uint16_t)(p[0]|((uint16_t)p[1]<<8));}
static void put16(uint8_t* p,uint16_t value){p[0]=(uint8_t)value;p[1]=(uint8_t)(value>>8);}
uint16_t hvgm_crc16(const uint8_t* data,size_t size){
    uint16_t crc=0xffff;
    for(size_t i=0;i<size;i++){
        crc^=(uint16_t)data[i]<<8;
        for(unsigned bit=0;bit<8;bit++)crc=(uint16_t)((crc&0x8000)?(crc<<1)^0x1021:crc<<1);
    }
    return crc;
}
static bool supported(const HvgmSettings* s){return s && !(s->flags&~3u) && !(s->effects&~7u);}
bool hvgm_encode(const HvgmSettings* s,uint8_t output[HVGM_WIRE_SIZE]){
    if(!supported(s)||!output)return false;
    memcpy(output,"HVG1",4);output[4]=HVGM_WIRE_VERSION;output[5]=s->flags;
    put16(output+6,s->revision);put16(output+8,s->bg);put16(output+10,s->fg);
    output[12]=s->effects;output[13]=0;put16(output+14,hvgm_crc16(output,14));return true;
}
HvgmResult hvgm_decode(const uint8_t* p,size_t n,HvgmSettings* output){
    if(!p||!output||n!=HVGM_WIRE_SIZE)return HvgmWrongLength;
    if(memcmp(p,"HVG1",4))return HvgmMagic;
    if(p[4]!=HVGM_WIRE_VERSION)return HvgmVersion;
    if((p[5]&~3u)||(p[12]&~7u)||p[13])return HvgmReserved;
    if(get16(p+14)!=hvgm_crc16(p,14))return HvgmChecksum;
    const HvgmSettings s={get16(p+6),get16(p+8),get16(p+10),p[5],p[12]};
    *output=s;return HvgmOk;
}
HvgmResult hvgm_revision_check(const HvgmRevisionState* state,const HvgmSettings* incoming){
    if(!state||!supported(incoming))return HvgmReserved;
    if(!state->valid)return HvgmOk;
    const HvgmSettings* s=&state->current;
    if(s->revision==incoming->revision){
        return s->bg==incoming->bg && s->fg==incoming->fg && s->flags==incoming->flags &&
            s->effects==incoming->effects ? HvgmDuplicate:HvgmConflict;
    }
    const uint16_t distance=(uint16_t)(incoming->revision-s->revision);
    return distance<0x8000?HvgmOk:HvgmStale;
}
void hvgm_revision_commit(HvgmRevisionState* state,const HvgmSettings* incoming){
    state->current=*incoming;state->valid=true;
}
void hvgm_resolve_palette(const HvgmSettings* s,uint16_t* bg,uint16_t* fg){
    *bg=(s->flags&HVGM_FLAG_INVERT)?s->fg:s->bg;
    *fg=(s->flags&HVGM_FLAG_INVERT)?s->bg:s->fg;
}
