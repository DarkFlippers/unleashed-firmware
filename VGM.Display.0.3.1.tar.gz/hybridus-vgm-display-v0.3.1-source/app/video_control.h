/* SPDX-License-Identifier: MIT */
#pragma once
#include "control_wire.h"
typedef enum {
    VideoControlFrame, VideoControlApplied, VideoControlDuplicate,
    VideoControlInvalidSettings, VideoControlStale, VideoControlBusy, VideoControlInvalidFrame
} VideoControlResult;
/* Core 0 only. Caller owns the revision state and resets it for each RPC session. */
VideoControlResult video_control_receive(HvgmRevisionState* state, uint8_t orientation,
    const uint8_t* data, size_t size);
