/* SPDX-License-Identifier: MIT */
#include "video_settings.h"
#include "settings_boot.h"
#include "frame.h"
#include <pico/mutex.h>
static VgmConfig desired;
static HvgmSettings last_host;
static bool last_host_valid;
auto_init_mutex(settings_mutex);
static void render_config(const VgmConfig*c,VideoRenderSettings*r){
 uint16_t bg=c->bg,fg=c->fg;if(c->flags&VGM_CONFIG_INVERT){uint16_t t=bg;bg=fg;fg=t;}frame_prepare_render(r,bg,fg,c->effects);
}
void video_settings_init(void){desired=settings_boot_config();last_host_valid=false;}
bool video_settings_get(VgmConfig*c){if(!c||!mutex_enter_timeout_ms(&settings_mutex,20))return false;*c=desired;mutex_exit(&settings_mutex);return true;}
bool video_settings_save_snapshot(VgmConfig*c){
 if(!c||!mutex_enter_timeout_ms(&settings_mutex,20))return false;
 *c=desired;
 if((desired.flags&VGM_CONFIG_HOST)&&last_host_valid){
  c->bg=last_host.bg;c->fg=last_host.fg;c->effects=last_host.effects;
  c->flags=VGM_CONFIG_HOST|((last_host.flags&HVGM_FLAG_INVERT)?VGM_CONFIG_INVERT:0);
 }
 mutex_exit(&settings_mutex);return true;
}
bool video_settings_set(const VgmConfig*c){
 if(!vgm_config_valid(c)||!mutex_enter_timeout_ms(&settings_mutex,20))return false;
 VideoRenderSettings r;render_config(c,&r);bool ok=frame_set_render(&r);
 if(ok){desired=*c;last_host_valid=false;}
 mutex_exit(&settings_mutex);return ok;
}
bool video_settings_frame(uint8_t orientation,const uint8_t*bitmap,const HvgmSettings*s,bool*applied){
 if(!bitmap||!applied||!mutex_enter_timeout_ms(&settings_mutex,20))return false;
 *applied=false;VideoRenderSettings r;const VideoRenderSettings*rp=NULL;
 // Explicit local manual mode has priority over any host trailer, including sync.
 if(s&&(desired.flags&VGM_CONFIG_HOST)){
  uint16_t bg,fg;hvgm_resolve_palette(s,&bg,&fg);frame_prepare_render(&r,bg,fg,s->effects);rp=&r;
 }
 bool ok=frame_apply(orientation,(const frame_t*)bitmap,rp,20);
 if(ok&&rp){*applied=true;last_host=*s;last_host_valid=true;}
 mutex_exit(&settings_mutex);return ok;
}

/* Explicit HVG2 commands: one bounded lock covers bitmap+render+desired state.
 * No persistence/hardware IO here. Called only from UART task, never callback. */
bool video_settings_command(uint8_t orientation,const uint8_t* bitmap,const VgmConfig* config){
 if(!bitmap||orientation>3||!vgm_config_valid(config)||!mutex_enter_timeout_ms(&settings_mutex,20))return false;
 VideoRenderSettings render;render_config(config,&render);
 bool ok=frame_apply(orientation,(const frame_t*)bitmap,&render,20);
 if(ok){desired=*config;last_host_valid=false;}
 mutex_exit(&settings_mutex);return ok;
}
