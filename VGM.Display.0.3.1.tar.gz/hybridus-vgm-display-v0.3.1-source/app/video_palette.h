// SPDX-License-Identifier: MIT
#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    uint16_t bg;
    uint16_t fg;
} VideoPalette;

#define VIDEO_PALETTE_DEFAULT_BG 0xFC00u
#define VIDEO_PALETTE_DEFAULT_FG 0x0000u

typedef enum {
    VideoPaletteInvalid = 0,
    VideoPaletteQuery,
    VideoPaletteUpdate,
} VideoPaletteResult;

/* Strict ASCII commands. Invalid/query never modify out; no heap or IO. */
VideoPaletteResult video_palette_command(
    const char* command, VideoPalette current, VideoPalette* out);

#ifdef __cplusplus
}
#endif
