/* SPDX-License-Identifier: MIT — final coordinated HVG2 wire contract. */
#include "hvg2-final.h"
#include <string.h>
static uint16_t get16(const uint8_t*p){return (uint16_t)(p[0]|((uint16_t)p[1]<<8));}
static void put16(uint8_t*p,uint16_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);}
uint16_t hvg2_crc16(const uint8_t*p,size_t n){uint16_t c=0xffff;for(size_t i=0;i<n;i++){c^=(uint16_t)p[i]<<8;for(unsigned b=0;b<8;b++)c=(uint16_t)((c&0x8000)?(c<<1)^0x1021:(c<<1));}return c;}
static bool valid(const Hvg2Command*c){return c&&c->effects<=7&&c->opcode>=Hvg2SetManual&&c->opcode<=Hvg2Save;}
static bool same(const Hvg2Command*a,const Hvg2Command*b){return a->fg==b->fg&&a->effects==b->effects&&a->invert==b->invert&&a->opcode==b->opcode;}
bool hvg2_encode(const Hvg2Command*c,uint8_t out[HVG2_WIRE_SIZE]){
 if(!valid(c)||!out)return false;
 memcpy(out,"HVG2",4);out[4]=2;out[5]=c->invert?1:0;put16(out+6,c->revision);put16(out+8,0);put16(out+10,c->fg);out[12]=c->effects;out[13]=(uint8_t)c->opcode;put16(out+14,hvg2_crc16(out,14));return true;
}
Hvg2Result hvg2_decode(const uint8_t*p,size_t n,Hvg2Command*out){
 if(!p||!out||n!=HVG2_WIRE_SIZE)return Hvg2Length;
 if(memcmp(p,"HVG2",4)||p[4]!=2||(p[5]&~1u)||get16(p+8)||p[12]>7||p[13]<1||p[13]>3)return Hvg2Format;
 if(get16(p+14)!=hvg2_crc16(p,14))return Hvg2Checksum;
 Hvg2Command c={get16(p+6),get16(p+10),p[12],!!(p[5]&1),(Hvg2Opcode)p[13]};*out=c;return Hvg2Ok;
}
Hvg2Result hvg2_check_revision(const Hvg2RevisionState*s,const Hvg2Command*c){
 if(!s||!valid(c))return Hvg2Format;
 if(!s->valid)return Hvg2Ok;
 const uint16_t d=(uint16_t)(c->revision-s->current.revision);
 if(!d)return same(c,&s->current)?Hvg2Duplicate:Hvg2Conflict;
 return d<0x8000?Hvg2Ok:Hvg2Stale;
}
void hvg2_commit_revision(Hvg2RevisionState*s,const Hvg2Command*c){s->current=*c;s->valid=true;}
