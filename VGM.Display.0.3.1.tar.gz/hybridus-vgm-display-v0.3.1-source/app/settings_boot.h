/* SPDX-License-Identifier: MIT */
#pragma once
#include "settings_store.h"
#ifdef __cplusplus
extern "C" {
#endif
/* Call exactly once, before ANY SDK init/cores/tasks/video. No runtime flash access. */
void settings_boot_init(void);
VgmConfig settings_boot_config(void);
VgmStoreResult settings_boot_result(void);
/* Explicit save only. Writes watchdog scratch and reboots, never writes flash here. */
bool settings_request_save(const VgmConfig*);
#ifdef __cplusplus
}
#endif
