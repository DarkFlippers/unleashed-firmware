# Hybridus VGM Display v0.3.1 source

This archive contains the reconstructed source tree corresponding to the published UF2 `vgm-fw-display-v0.3.1-bezel-preview.uf2`.

Base: official `flipperdevices/video-game-module` release 0.1.0, commit `f18ad4481ef04449aaae55a4d5556923effef276`.

This is an unofficial independent modification. Preserve all component notices and licenses in `lib/` and source headers. See the repository's `THIRD_PARTY_NOTICES.md`. No blanket root license is asserted for the mixed tree.
